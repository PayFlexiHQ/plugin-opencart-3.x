<?php
// Text
$_['text_title'] = 'Pay in InstalLments (via PayFlexi)';
$_['text_testmode'] = 'Warning: The payment gateway is in \'Test Mode\'. Only a  test details can be used.';
